<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<!--
		*******************************************************************************

		I M P O R T A N T -- N O T I C E
		- - - - - - - - -    - - - - - -

		created by MUhammad Abba Gana

		Do NOT copy and paste this code from a web browser "View Source" Window.

		The actual code contains server-side function calls which do not appear in a
		"View Source" situation even copy cannot work!!

		Please refer to the supplied templates on the product CD.
		
			for more contact me on the following details;

			email address: abbagana79@gmail.com
			phone number: +2349039016969
			website:www.Guidetricks.blogspot.com

		*******************************************************************************
	-->
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Chat System</title>
<body bgcolor="pink">
    <font size="5pt" face="Calibri" color="black">
</head><center>
Hello you are Higly Welcome, this is a simple chatting system created in other to make information transmission very easily please don't use this as an opportunity to abuse,verbal malteatment, assault, displaying attempts to harbour irrelevant materials/links, violation or  crime if found with one of the followings you will definately banned from accessing!!
<br />
<p><h1>Choose Below to Continue</h1><a><strong>
<a href="@@cht">Group Chat</p></a>
<br /><br>
</br></br><a href="logout.php">Log Out</a>
<body>
</body>
<br /><br><br /><br><br /><br><br />
</html>
